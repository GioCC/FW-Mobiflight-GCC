Mobiflight-src-GCC

Evoluzione del progetto MobiFlight per estensione a moduli I/O a banchi multipli (WIP)
Inizialmente solo per SW Arduino, possibilmente poi anche sw C#
Repository originale:   https://bitbucket.org/mobiflight/mobiflightfc/overview
Versione base:          2017-09-05
